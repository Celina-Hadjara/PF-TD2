package universite;

import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

public class MesFonctions {
    public static void afficheSi(String EnTete, Predicate<Etudiant> PredEtudiant, Annee annee) {
        System.out.println(EnTete);
        for (Etudiant i : annee.etudiants()) {
            if (PredEtudiant.test(i)) {
                System.out.println(i.toString());
            }
        }
    }

    //afficheSi avec forech
    public static void afficheSi1(String EnTete, Predicate<Etudiant> PredEtudiant, Annee annee) {
        System.out.println(EnTete);

        annee.etudiants().forEach(etudiant->{
            if (PredEtudiant.test(etudiant)) {
                System.out.println(etudiant.toString());
            }
        });
    }

    public static Double moyenne (Etudiant etudiant) {
        double laMoyenne = 0;
        int sommeEcts = 0;
        if (MesPrediates.aDEF.test(etudiant)) return null;
        for (UE ue :etudiant.annee().ues()) {
            for (Map.Entry<Matiere, Integer> ects : ue.ects().entrySet()) {
                laMoyenne += etudiant.notes().get(ects.getKey())*ects.getValue();
                sommeEcts+= ects.getValue();
            }
        }
        return laMoyenne/sommeEcts;
    }

    public static void afficheSi2(String EnTete, Predicate<Etudiant> PredEtudiant, Annee annee, Function function) {
        System.out.println(EnTete);
        for (Etudiant i : annee.etudiants()) {
            if (PredEtudiant.test(i)) {
                System.out.println(function);
            }
        }
    }

    public static Double moyenneIndicative(Etudiant etudiant){
        double laMoyenne = 0;
        int sommeEcts = 0;
        for (UE ue :etudiant.annee().ues()) {
            for (Map.Entry<Matiere, Integer> ects : ue.ects().entrySet()) {
                if (MesPrediates.aDEF.test(etudiant)){
                    etudiant.notes().put(ects.getKey(),0.0);
                }
                laMoyenne += etudiant.notes().get(ects.getKey())*ects.getValue();
                sommeEcts+= ects.getValue();
            }
        }
        return laMoyenne/sommeEcts;
    }

    public static boolean naPasLaMoyenneGeneralise(Etudiant etudiant){
        if(MesPrediates.aDEF.test(etudiant)) return moyenneIndicative(etudiant)<10;
        return moyenne(etudiant)<10;
    }
}
