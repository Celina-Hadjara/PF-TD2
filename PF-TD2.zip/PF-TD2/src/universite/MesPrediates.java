package universite;


import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class MesPrediates {
    Somme<Integer> sommeInt =
            (Integer x, Integer y) -> x+y;

    Somme<String> sommeString =
            (String x, String y) -> x+y;

    Somme <Double> sommeDouble =
            (Double x, Double y) -> x+y;

    Somme <Long> sommeLong =
            (Long x, Long y) -> x+y;

    ToString<List<String>> listToString=(list)->
            list.stream().reduce("",(String a, String b)->a+" ,"+b);

    Map<String,Integer> map=Map.of("L3",23,"M1",25,"M2",30);

    ToString<Map<Integer,String>> mapToString = (x)-> map.keySet()
            .stream()
            .map(key->key + ": " + map.get(key)).collect(Collectors.joining(","));

    public static Predicate<Etudiant> aDEF = (etudiant)-> {
        for (UE ue: etudiant.annee().ues()) {
            for (Map.Entry<Matiere, Integer> ects : ue.ects().entrySet()) {
                if( ! etudiant.notes().containsKey(ects.getKey()) ) {
                    return true;
                }
            }
        }
        return false;
    };

    /**
     * Question 3
     * Function: Prends un argument (T) et retourne un (R), c'est à dire T convertie en R
     * Predicate: Prends un argument (T) et retourne un boolean
     * Consumer: Prends un argument (T) et ne retourne aucune valeur
     * Supplier: Ne prends rien en argument et retourne (T)
     */

    public static Predicate<Etudiant> aNoteEliminatoire = a -> {
        for (Double note : a.notes().values()) {
            if (note < 6.0)
                return true;
        }

        return false;
    };

    /**
     * Without try catch, this predicate make a null pointer exception
     * Because we can't compare null with double
     */
    public static Predicate<Etudiant>  naPasLaMoyennev1 = etudiant -> {
        try {
            return MesFonctions.moyenne(etudiant) < 10;
        }catch (NullPointerException e){
            System.err.println();
        }
        return false;
    };

    public static Predicate<Etudiant> naPasLaMoyennev2 = etudiant ->{
        return aDEF.or(naPasLaMoyennev1).test(etudiant);
    } ;

    /**
     * On observe que l'ordre des test (d'excecution) correspond aux mêmes ordres
     * dans la disjonction logique des prédicats
     */
    public static Predicate<Etudiant> session2v1 = etudiant -> {
        return aDEF.or(aNoteEliminatoire).or(naPasLaMoyennev1).test(etudiant);
    };

}
